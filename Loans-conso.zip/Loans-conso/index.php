<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">

  window.history.forward();
</script>
	<title>LOGIN</title>
	<meta charset="UTF-8">
	<meta name="author" content="">
 <link rel="icon" href="Img/LIS.png">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/animate/animate.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/select2/select2.min.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="resources/vendor/css/util.css">
		<link rel="stylesheet" type="text/css" href="resources/vendor/css/main.css">
	<!--===============================================================================================-->
</head>
<body>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-80 p-r-80 p-t-25 p-b-20">
				<form action="Logincon.php" method="POST" class="login100-form validate-form">

					<span class="login100-form-title p-b-5">
						<div class="row">
						<div class="col">
						</div>
						<div class="col">
						<img src="img/pdblogo.jpg" width="150" height="80" class="d-inline-block align-bottom">
						</div>
						<div class="col">
						</div>
					</div>

						<font size="2">Online Loans Information System</font><br style="margin:0">
						<h6 class="text-dark"><b>CONSOLIDATED</b></h6>


					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="ui" name="ui" placeholder="User ID">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-10">
						<button  class="login100-form-btn">
							Login
						</button>
					</div>

				</form>
			</div>
		</div>
	</div>



	<!--===============================================================================================-->
		<script src="resources/vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
		<script src="resources/vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
		<script src="resources/vendor/bootstrap/js/popper.js"></script>
		<script src="resources/vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
		<script src="resources/vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
		<script src="resources/vendor/daterangepicker/moment.min.js"></script>
		<script src="resources/vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
		<script src="resources/vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
		<script src="/resources/vendor/js/main.js"></script>

</body>
</html>
