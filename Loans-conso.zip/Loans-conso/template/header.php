<?php  session_start();
$ui = $_SESSION['uid'];

if ($ui != NULL) {

require "connection.php";
$timezone = "Asia/Colombo";
date_default_timezone_set($timezone);
$today = date("Y-m-d");

 ?>

 <meta charset='utf-8'>
 <meta name='viewport' content='width=device-width, initial-scale=1'>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
 <meta name="author" content="">
<link rel="icon" href="Img/LIS.PNG">
 <!-- jQuery -->
 <script src="resources/jquery/3.5.1/jquery.min.js"></script>

 <!-- Bootstrap -->
 <link rel="stylesheet" href="resources/bootstrap/4.4.1/css/bootstrap.min.css">
 <script src="resources/popper/1.16.0/popper.min.js"></script>
 <script src="resources/bootstrap/4.4.1/js/bootstrap.min.js"></script>

 <!-- Font Awesome -->
 <link rel="stylesheet" href="resources/fontawesome/4.7.0/css/font-awesome.min.css">

 <!-- Datatables -->
 <link rel="stylesheet" href="resources/datatables/1.10.23/css/dataTables.bootstrap4.min.css">
 <script src="resources/datatables/1.10.23/js/jquery.dataTables.min.js"></script>
 <script src="resources/datatables/1.10.23/js/dataTables.bootstrap4.min.js"></script>

 <style media="screen">
   /* Chrome, Safari, Edge, Opera */
     input::-webkit-outer-spin-button,
     input::-webkit-inner-spin-button {
     -webkit-appearance: none;
     margin: 0;
     }
     .input-sm {
     height: 25px;
     padding: 3px 5px;
     font-size: 12px;
     line-height: 1.5; /* If Placeholder of the input is moved up, rem/modify this. */
     border-radius: 3px;
     margin-bottom: 3px;
     }

     .text-sm {
     height: 20px;
     padding: 3px 5px;
     font-size: 12px;
     line-height: 1.5; /* If Placeholder of the input is moved up, rem/modify this. */
     border-radius: 3px;
     margin-bottom: 0px;
     vertical-align: middle;
     }
     #header {
       position: relative;
     }

     #header span {
       position: absolute;
       bottom: 0;
     }
     .br {
      display: block;
      margin-bottom: 0em;
  }
 </style>
<nav class="navbar navbar-expand-lg navbar-light bg-success text-light" style="font-family:Arial">
  <div class="container">
    <a class="navbar-brand" href="Dashboard.php" style="">
          <img src="Img\pdblogo.png" alt="" width="70" height="35">
        <font class="text-light text-bottom" style="font-family:time-new-roman;font-size:20px;vertical-align:bottom;"> Pampanga Development Bank</font>
    </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  &nbsp&nbsp
  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" style="margin-top:10px;" aria-haspopup="true" aria-expanded="false">
          <b>Menu</b>
          </a>

        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="Dashboard.php">Dashboard</a>
          <a class="dropdown-item" href="LoanReport.php">Loan Report</a>
          <a class="dropdown-item" href="nfispastdue.php">NFIS Monitoring</a>
        </div>
      </li>
    </ul>
    <div class="col text-right">
       <label class="text-light" style="margin-bottom:0em"><b><?php echo $Branch; ?></b></label>
        |
       <label style="margin-bottom:0em"><?php echo $ui; ?></label>
        |
       <a class="active text-white" href="logout.php" style="margin-bottom:0em">Logout </a>
       <span class="br"></span>
       <?php
        require 'connection.php';
        $sql = "SELECT	'SF',FORMAT(LoansStartDateTime,'MM-dd') LoansStartDate,
                       FORMAT(LoansEndDateTime ,'MM-dd') LoansEndDate
                    FROM $DB1.dbo.genBranch
                    WHERE BranchNo = 1
                    UNION ALL
                SELECT 'AC',FORMAT(LoansStartDateTime,'MM-dd') LoansStartDate,
                       FORMAT(LoansEndDateTime ,'MM-dd') LoansEndDate
                    FROM $DB2.dbo.genBranch
                    WHERE BranchNo = 2
                    UNION ALL
                SELECT 'TC',FORMAT(LoansStartDateTime,'MM-dd') LoansStartDate,
                       FORMAT(LoansEndDateTime ,'MM-dd') LoansEndDate
                    FROM $DB3.dbo.genBranch
                    WHERE BranchNo = 3
                    UNION ALL
                SELECT 'CC',FORMAT(LoansStartDateTime,'MM-dd') LoansStartDate,
                       FORMAT(LoansEndDateTime ,'MM-dd') LoansEndDate
                    FROM $DB4.dbo.genBranch
                     WHERE BranchNo = 4";
        $stmt = sqlsrv_query($conn, $sql,);
        ?>
        <span class="text-dark bg-light" style="margin:0;font-size:10px;padding:2px">Loan Start Date :</span>
        <?php

            while($row = sqlsrv_fetch_array($stmt)){
                      ?>
                      <font style="margin:0em;font-size:10px;padding:2px" class="text-dark bg-light"><?php echo   $row[0] .' - '. $row[1]?></font>
                      <?php
                    }
            sqlsrv_free_stmt($stmt);

        ?>
         <label for=""></label>
    </div>
  </div>
  </div>
</nav>

<div class="container-fluid">


  <?php
  }else {
    header('location:index.php');
  }
   ?>
